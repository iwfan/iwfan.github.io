export default function sum(a: number, b: number) {
  return a + b;
}
export function fun1() {}
export function fun2() {}
