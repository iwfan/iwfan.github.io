import sum from "../src/index";

test("sum should return 2 when given 1 1", () => {
  expect(sum(1, 1)).toBe(2);
});
