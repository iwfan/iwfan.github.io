import { registerApplication, start as startApps } from 'single-spa/lib/esm/single-spa.dev'
import { importEntry, Entry, ImportEntryOpts } from 'import-html-entry'

type App<T extends object = {}> = {
  name: string; // app name
  entry: Entry; // app entry
  activeRule: (location: Location) => boolean;
  customProps?: T; // props pass through to app
  render: (props: { appContent: string }) => any;
};

function getWrapperId(appName: string): string {
  return `__wrapper_for_${appName}__`;
}

const registeredApps = []

export function registerApps<T extends object = {}>(apps: Array<App<T>>, opts: Omit<ImportEntryOpts, 'getTemplate'>) {
  apps.forEach(app => {
    const { name, activeRule, entry, customProps, render } = app
    registeredApps.push(
      registerApplication(
        name,
        async ({ name: appName }) => {
          // get the entry html content and script executor
          const { template: appContent, execScripts } = await importEntry(entry, {
            getTemplate: (tpl: string) => `<div id="${getWrapperId(appName)}" style="position: relative;">${tpl}</div>`,
            ...opts,
          })
          const { bootstrap, mount, unmount } = await execScripts()

          return {
            bootstrap: [bootstrap],
            mount: [
              render({ appContent }),
              mount
            ],
            unmount: [
              unmount,
              render({ appContent: '' })
            ]
          }
        },
        activeRule,
        customProps
      )
    )
  })
}

export function start() {
  startApps()
}
