import { registerApps, start } from 'chassis'

function render({ appContent }) {
  return () => {
    document.querySelector('main').innerHTML = appContent
    return Promise.resolve()
  }
}

registerApps([
  {
    name: 'app-vue', // app name
    entry: '//localhost:8080', // app entry
    activeRule: (location) => location.pathname.startsWith('/app-vue'),
    render,
    customProps: { injectedProps: { foo: 'foo' } }
  },
  {
    name: 'app-ng', // app name
    entry: '//localhost:4200', // app entry
    activeRule: (location) => location.pathname.startsWith('/app-ng'),
    render,
    customProps: { injectedProps: { foo: 'foo' } }
  }
], {})

start()