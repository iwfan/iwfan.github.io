const singleSpaAngularWebpack = require('single-spa-angular/lib/webpack').default
const ExtractPlugin = require("extract-plugin");

module.exports = (angularWebpackConfig, options) => {
  const singleSpaWebpackConfig = singleSpaAngularWebpack(angularWebpackConfig, options)

  // Feel free to modify this webpack config however you'd like to
  singleSpaWebpackConfig.plugins.push(new ExtractPlugin(["data-service"]));

  return singleSpaWebpackConfig
}
