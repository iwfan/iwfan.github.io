import { Component } from '@angular/core';

import sum from 'data-service';

console.log(`%c[angular import foo] ${sum(1, 2)}`, 'color: #e74c3c')

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app-ng';
}
