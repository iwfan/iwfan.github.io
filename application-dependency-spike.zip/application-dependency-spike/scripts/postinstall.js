const shell = require('shelljs');

shell.cd('libs/chassis');

shell.exec('yarn link');

shell.cd('../../dependencies/data-service');

shell.exec('yarn link');

shell.echo('link end')

shell.cd('../../applications');

shell.exec('yarn link chassis');

shell.exec('yarn link data-service');

