# Getting Start

```shell script
git clone git@gitlab.com:micro-frontends-squad/application-dependency-spike.git

cd application-dependency-spike

yarn install

cd libs/chassis

yarn build

cd ../../dependencies/data-service

yarn build

cd ../../

yarn start
```


# Development Applications

```shell script

cd applications/app-ng

yarn start
```


# Project Structure
```text
.
├── README.md
├── applications          # micro front-end applications
│   ├── app-ng
│   ├── app-vue
│   └── root
├── dependencies          # shared dependencies
│   ├── data-service
│   └── imports
├── libs                  # core
│   └── chassis
├── package.json
├── scripts
│   └── postinstall.js
└── yarn.lock
```

> `tree . -L 2 -I 'node_modules'`
