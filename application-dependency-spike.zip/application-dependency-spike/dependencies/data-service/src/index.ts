export default function sum(a: number, b: number) {
  return a + b;
}
